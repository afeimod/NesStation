//afbn专用Aces高清滤镜，碎总制作，afbn交流群号：556297887；
#define saturate(c) clamp(c, 0.0, 1.0)
#define lerp(a,b,c) mix(a,b,c)
#define mul(a,b) (b*a)
#define fmod(c,d) mod(c,d)
#define frac(c) fract(c)
#define rsqrt(x)  1.0/sqrt(x)
#define rcp(x)  1.0/x
#define float2 vec2
#define float3 vec3
#define float4 vec4
#define int2 ivec2
#define int3 ivec3
#define int4 ivec4
#define bool2 bvec2
#define bool3 bvec3
#define bool4 bvec4
#define float2x2 mat2x2
#define float3x3 mat3x3
#define float4x4 mat4x4

#if defined(VERTEX)

#if __VERSION__ >= 130
#define COMPAT_VARYING out
#define COMPAT_ATTRIBUTE in
#define COMPAT_TEXTURE texture
#else
#define COMPAT_VARYING varying 
#define COMPAT_ATTRIBUTE attribute 
#define COMPAT_TEXTURE texture2D
#endif

#ifdef GL_ES
#define COMPAT_PRECISION mediump
#else
#define COMPAT_PRECISION
#endif

COMPAT_ATTRIBUTE vec4 VertexCoord;
COMPAT_ATTRIBUTE vec4 COLOR;
COMPAT_ATTRIBUTE vec4 TexCoord;
COMPAT_VARYING vec4 COL0;
COMPAT_VARYING vec4 TEX0;

vec4 _oPosition1; 
uniform mat4 MVPMatrix;
uniform COMPAT_PRECISION int FrameDirection;
uniform COMPAT_PRECISION int FrameCount;
uniform COMPAT_PRECISION vec2 OutputSize;
uniform COMPAT_PRECISION vec2 TextureSize;
uniform COMPAT_PRECISION vec2 InputSize;

void main()
{
    gl_Position = MVPMatrix * VertexCoord;
    COL0 = COLOR;
    TEX0.xy = TexCoord.xy;
}

#elif defined(FRAGMENT)

#if __VERSION__ >= 130
#define COMPAT_VARYING in
#define COMPAT_TEXTURE texture
out vec4 FragColor;
#else
#define COMPAT_VARYING varying
#define FragColor gl_FragColor
#define COMPAT_TEXTURE texture2D
#endif

#ifdef GL_ES
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
precision mediump int;
#endif
#define COMPAT_PRECISION mediump
#else
#define COMPAT_PRECISION
#endif

uniform COMPAT_PRECISION int FrameDirection;
uniform COMPAT_PRECISION int FrameCount;
uniform COMPAT_PRECISION vec2 OutputSize;
uniform COMPAT_PRECISION vec2 TextureSize;
uniform COMPAT_PRECISION vec2 InputSize;
uniform sampler2D Texture;
COMPAT_VARYING vec4 TEX0;
#define SourceSize vec4(TextureSize, 1.0 / TextureSize) 

vec3 ACES_Tonemap_core(vec3 color, float exposure, float contrast) {
	vec3 exposed = color * exposure;

	const mat3 AP0_TO_AP1 = mat3(
		0.597190000000000, 0.076000000000000, 0.028400000000000,
		0.354580000000000, 0.908340000000000, 0.133830000000000,
		0.048230000000000, 0.015660000000000, 0.837770000000000
	);

	vec3 ap1 = AP0_TO_AP1 * exposed;

	const vec3 LUMINANCE_AP1 = vec3(0.27222871678091454, 0.67408176581114831, 0.05368951740793705);
	float luma = dot(ap1, LUMINANCE_AP1);
	float compressed = luma <= 0.002 ? luma * 2.0 : log2(luma * 0.5 + 1.0);

	float sat_factor = 1.0 - 0.4 * clamp(compressed, 0.0, 1.0);
	vec3 adjusted = vec3(compressed) + (ap1 - luma) * sat_factor;

	vec3 a = adjusted * (adjusted + 0.0245786) - 0.000090537;
	vec3 b = adjusted * (0.983729 * adjusted + 0.4329510) + 0.238081;
	vec3 rrt = a / (b + 1e-8);

	const mat3 ACES_OUTPUT = mat3(
		1.604750000000000, -0.102080000000000, -0.003270000000000,
		-0.531080000000000, 1.108130000000000, -0.072760000000000,
		-0.073670000000000, -0.006050000000000, 1.076020000000000
	);

	vec3 outColor = ACES_OUTPUT * rrt;

	vec3 contrast_adj = (outColor - 0.5) * contrast + 0.5;
	outColor = mix(outColor, contrast_adj, vec3(0.5));
	return clamp(outColor, vec3(0.0), vec3(1.0));
}

vec3 ACES_Tonemap(vec3 color, float exposure, float contrast) {
	return ACES_Tonemap_core(color, exposure, contrast);
}

vec3 ACES_Tonemap(vec3 color) {
	return ACES_Tonemap_core(color, 1.0, 1.0);
}

vec3 ACES_GameToneMap(vec3 color) {
	return ACES_Tonemap_core(color * 1.0, 1.0, 1.0);
}

vec4 coolTintFilter(vec3 colorIn) {
	vec4 P = (colorIn.g < colorIn.b) ? vec4(colorIn.bg, -1.0, 2.0/3.0) : vec4(colorIn.gb, 0.0, -1.0/3.0);
	vec4 Q = (colorIn.r < P.x) ? vec4(P.xyw, colorIn.r) : vec4(colorIn.r, P.yzx);
	float C_hcv = Q.x - min(Q.w, Q.y);
	float H_hcv = C_hcv > 0.0001 ? abs((Q.w - Q.y) / (6.0 * C_hcv) + Q.z) : 0.0;
	float V_hcv = Q.x;
	vec3 HCV = vec3(H_hcv, C_hcv, V_hcv);

	float L_olum = HCV.z - HCV.y * 0.5;

	const vec3 kCoolColor = vec3(0.45, 0.65, 1.0);
	float blendFactor = 0.35;
	vec3 blended = mix(colorIn, colorIn * kCoolColor, blendFactor);

	vec4 P_blend = (blended.g < blended.b) ? vec4(blended.bg, -1.0, 2.0/3.0) : vec4(blended.gb, 0.0, -1.0/3.0);
	vec4 Q_blend = (blended.r < P_blend.x) ? vec4(P_blend.xyw, blended.r) : vec4(blended.r, P_blend.yzx);
	float C_blend = Q_blend.x - min(Q_blend.w, Q_blend.y);
	float H_blend = C_blend > 0.0001 ? abs((Q_blend.w - Q_blend.y) / (6.0 * C_blend) + Q_blend.z) : 0.0;
	float V_blend = Q_blend.x;
	vec3 HCV_blend = vec3(H_blend, C_blend, V_blend);

	float L_blend = HCV_blend.z - HCV_blend.y * 0.5;
	float S_blend = C_blend > 0.0001 ? HCV_blend.y / (1.0 - abs(L_blend * 2.0 - 1.0)) : 0.0;
	vec3 HSL_blend = vec3(H_blend, S_blend, L_blend);

	float H = HSL_blend.x;
	float S = HSL_blend.y;
	float L = HSL_blend.z;

	float C_hsl = (1.0 - abs(2.0 * L - 1.0)) * S;
	float X = C_hsl * (1.0 - abs(mod(H * 6.0, 2.0) - 1.0));
	float m = L - C_hsl * 0.5;
	vec3 RGB_hue;
	if (H < 1.0/6.0) {
		RGB_hue = vec3(C_hsl, X, 0.0);
	} else if (H < 2.0/6.0) {
		RGB_hue = vec3(X, C_hsl, 0.0);
	} else if (H < 3.0/6.0) {
		RGB_hue = vec3(0.0, C_hsl, X);
	} else if (H < 4.0/6.0) {
		RGB_hue = vec3(0.0, X, C_hsl);
	} else if (H < 5.0/6.0) {
		RGB_hue = vec3(X, 0.0, C_hsl);
	} else {
		RGB_hue = vec3(C_hsl, 0.0, X);
	}

	vec3 finalColor = RGB_hue + vec3(m);

	finalColor = clamp(finalColor, 0.0, 1.0);

	return vec4(finalColor, 1.0);
}

vec3 CurveAdjust(vec3 color) {
	const vec3 LUMA_COEFF = vec3(0.2126, 0.7152, 0.0722);
	float luma = dot(color, LUMA_COEFF);
	color = (color + (color - luma) * 1.0) / (1.0 + (color - luma) * 1.0);
	return color;
}

float luma(vec3 col){
   return dot(col, vec3(0.2126, 0.7152, 0.0722));
}
#define src(c,d) texture2D(Texture, TEX0.xy + vec2(c,d) * SourceSize.zw).rgb

vec3 scale(vec3 color) {
   float srcX = 0.;
   float srcY = 0.;

   vec3 A = src(srcX-1.,srcY-1.);
   vec3 B = src(srcX+0.,srcY-1.);
   vec3 C = src(srcX+1.,srcY-1.);
   vec3 D = src(srcX-1.,srcY+0.);
   vec3 E = src(srcX+0.,srcY+0.);
   vec3 F = src(srcX+1.,srcY+0.);
   vec3 G = src(srcX-1.,srcY+1.);
   vec3 H = src(srcX+0.,srcY+1.);
   vec3 I = src(srcX+1.,srcY+1.);

   bool allSame = 
      all(equal(E,A)) && all(equal(E,B)) && all(equal(E,C)) && 
      all(equal(E,D)) && all(equal(E,F)) && all(equal(E,G)) && 
      all(equal(E,H)) && all(equal(E,I));
   if(allSame) {
      FragColor.rgb = E;
      FragColor.a = 1.0;
      return E;
   }

   vec3 P  = src(srcX+0.,srcY-2.);
   vec3 Q  = src(srcX-2.,srcY+0.);
   vec3 R  = src(srcX+2.,srcY+0.);
   vec3 S  = src(srcX+0.,srcY+2.);

   float Bl = luma(B), Dl = luma(D), El = luma(E), Fl = luma(F), Hl = luma(H);

   vec3 J = E, K = E, L = E, M = E;

   #define same(a,b) all(equal(a,b))
   #define notsame(a,b) any(notEqual(a,b))

   if (same(D,B) && notsame(D,H) && notsame(D,F) && (El>=Dl || same(E,A)) && 
       (same(E,A) || same(E,C) || same(E,G)) && (El<Dl || notsame(A,D) || notsame(E,P) || notsame(E,Q))) J=D;

   if (same(B,F) && notsame(B,D) && notsame(B,H) && (El>=Bl || same(E,C)) && 
       (same(E,A) || same(E,C) || same(E,I)) && (El<Bl || notsame(C,B) || notsame(E,P) || notsame(E,R))) K=B;

   if (same(H,D) && notsame(H,F) && notsame(H,B) && (El>=Hl || same(E,G)) && 
       (same(E,A) || same(E,G) || same(E,I)) && (El<Hl || notsame(G,H) || notsame(E,S) || notsame(E,Q))) L=H;

   if (same(F,H) && notsame(F,B) && notsame(F,D) && (El>=Fl || same(E,I)) && 
       (same(E,C) || same(E,G) || same(E,I)) && (El<Fl || notsame(I,H) || notsame(E,R) || notsame(E,S))) M=F;

   if (notsame(E,F) && same(E,C) && same(E,I) && same(E,D) && same(E,Q) && same(F,B) && same(F,H) && notsame(F,src(srcX+3.,srcY))) K=M=F;
   if (notsame(E,D) && same(E,A) && same(E,G) && same(E,F) && same(E,R) && same(D,B) && same(D,H) && notsame(D,src(srcX-3.,srcY))) J=L=D;
   if (notsame(E,H) && same(E,G) && same(E,I) && same(E,B) && same(E,P) && same(H,D) && same(H,F) && notsame(H,src(srcX,srcY+3.))) L=M=H;
   if (notsame(E,B) && same(E,A) && same(E,C) && same(E,H) && same(E,S) && same(B,D) && same(B,F) && notsame(B,src(srcX,srcY-3.))) J=K=B;

   if (Bl<El && same(E,G) && same(E,H) && same(E,I) && same(E,S) && notsame(E,A) && notsame(E,D) && notsame(E,C) && notsame(E,F)) J=K=B;
   if (Hl<El && same(E,A) && same(E,B) && same(E,C) && same(E,P) && notsame(E,D) && notsame(E,G) && notsame(E,I) && notsame(E,F)) L=M=H;
   if (Fl<El && same(E,A) && same(E,D) && same(E,G) && same(E,Q) && notsame(E,B) && notsame(E,C) && notsame(E,I) && notsame(E,H)) K=M=F;
   if (Dl<El && same(E,C) && same(E,F) && same(E,I) && same(E,R) && notsame(E,B) && notsame(E,A) && notsame(E,G) && notsame(E,H)) J=L=D;

   if (notsame(H,B)) { 
      if (notsame(H,A) && notsame(H,E) && notsame(H,C)) {
         if (same(H,G) && same(H,F) && same(H,R) && notsame(H,D) && notsame(H,src(srcX+2.,srcY-1.))) L=M;
         if (same(H,I) && same(H,D) && same(H,Q) && notsame(H,F) && notsame(H,src(srcX-2.,srcY-1.))) M=L;
      }
      if (notsame(B,I) && notsame(B,G) && notsame(B,E)) {
         if (same(B,A) && same(B,F) && same(B,R) && notsame(B,D) && notsame(B,src(srcX+2.,srcY+1.))) J=K;
         if (same(B,C) && same(B,D) && same(B,Q) && notsame(B,F) && notsame(B,src(srcX-2.,srcY+1.))) K=J;
      }
   }

   if (notsame(F,D)) { 
      if (notsame(D,I) && notsame(D,E) && notsame(D,C)) {
         if (same(D,A) && same(D,H) && same(D,S) && notsame(D,B) && notsame(D,src(srcX+1.,srcY+2.))) J=L;
         if (same(D,G) && same(D,B) && same(D,P) && notsame(D,H) && notsame(D,src(srcX+1.,srcY-2.))) L=J;
      }
      if (notsame(F,E) && notsame(F,A) && notsame(F,G)) {
         if (same(F,C) && same(F,H) && same(F,S) && notsame(F,B) && notsame(F,src(srcX-1.,srcY+2.))) K=M;
         if (same(F,I) && same(F,B) && same(F,P) && notsame(F,H) && notsame(F,src(srcX-1.,srcY-2.))) M=K;
      }
   }
   vec2 a = fract(TEX0.xy * SourceSize.xy);
   FragColor.rgb = a.x < 0.5 ? (a.y < 0.5 ? J : L) : (a.y < 0.5 ? K : M);
   FragColor.a = 1.0;
   return FragColor.xyz;
}


void main()
{   
    vec3 color = texture2D(Texture, TEX0.xy).rgb;     
          color = scale(color);
    color = coolTintFilter(color.xyz).rgb;
	vec3 white_mapped = ACES_Tonemap_core(vec3(1.0), 1.0, 1.0);
	vec3 mapped = ACES_GameToneMap(color.rgb) / (white_mapped + 1e-8);

	float lift = 0.15;
	color = mapped * (1.0 + lift) / (1.0 + mapped * lift);
  
   gl_FragColor = vec4(clamp(color, 0.0, 1.0), 1.0);
	
}
#endif