#ifdef GL_ES
precision mediump float;
#endif

varying vec4 TEX0;
uniform sampler2D Texture;

void main()
{
	gl_FragColor = texture2D(Texture, TEX0.xy);
}
