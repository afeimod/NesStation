#ifdef GL_ES
precision mediump float;
#endif

varying vec4 TEX0;
uniform sampler2D Texture;
uniform vec2 TextureSize;

void main()
{
	vec2 texel = 1.0 / TextureSize;
	vec3 center = texture2D(Texture, TEX0.xy).rgb * 5.0;
	vec3 left = texture2D(Texture, TEX0.xy - vec2(texel.x, 0.0)).rgb;
	vec3 right = texture2D(Texture, TEX0.xy + vec2(texel.x, 0.0)).rgb;
	vec3 up = texture2D(Texture, TEX0.xy - vec2(0.0, texel.y)).rgb;
	vec3 down = texture2D(Texture, TEX0.xy + vec2(0.0, texel.y)).rgb;
	gl_FragColor = vec4(clamp(center - left - right - up - down, 0.0, 1.0), 1.0);
}
