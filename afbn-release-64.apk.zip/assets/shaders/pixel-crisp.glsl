#ifdef GL_ES
precision mediump float;
#endif

varying vec4 TEX0;
uniform sampler2D Texture;
uniform vec2 TextureSize;

void main()
{
	vec2 uv = (floor(TEX0.xy * TextureSize) + 0.5) / TextureSize;
	vec3 c = texture2D(Texture, uv).rgb;
	gl_FragColor = vec4(c, 1.0);
}
