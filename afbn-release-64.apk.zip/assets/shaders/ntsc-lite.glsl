#ifdef GL_ES
precision mediump float;
#endif

varying vec4 TEX0;
uniform sampler2D Texture;
uniform vec2 TextureSize;

void main()
{
	vec2 uv = TEX0.xy;
	vec2 dx = vec2(1.0 / TextureSize.x, 0.0);
	vec3 c0 = texture2D(Texture, uv).rgb;
	vec3 c1 = texture2D(Texture, uv - dx).rgb;
	vec3 c2 = texture2D(Texture, uv + dx).rgb;
	vec3 blur = c0 * 0.72 + (c1 + c2) * 0.14;
	float phase = sin((gl_FragCoord.x + gl_FragCoord.y * 0.25) * 2.0943951);
	vec3 bleed = vec3(phase * 0.025, -phase * 0.018, phase * 0.012);
	vec3 color = mix(c0, blur + bleed, 0.24);
	gl_FragColor = vec4(clamp(color, 0.0, 1.0), 1.0);
}
