#ifdef GL_ES
precision mediump float;
#endif

varying vec4 TEX0;
uniform sampler2D Texture;
uniform vec2 TextureSize;

void main()
{
	vec2 uv = (floor(TEX0.xy * TextureSize) + 0.5) / TextureSize;
	vec3 c = texture2D(Texture, uv).rgb;
	float triad = mod(gl_FragCoord.x, 3.0);
	vec3 mask = triad < 1.0 ? vec3(1.14, 0.90, 0.90)
			: (triad < 2.0 ? vec3(0.90, 1.14, 0.90) : vec3(0.90, 0.90, 1.14));
	float line = mix(0.82, 1.04, step(0.5, fract(gl_FragCoord.y * 0.5)));
	c = pow(c, vec3(0.94)) * mask * line;
	gl_FragColor = vec4(clamp(c, 0.0, 1.0), 1.0);
}
