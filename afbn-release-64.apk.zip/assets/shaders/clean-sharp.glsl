#ifdef GL_ES
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
#endif

varying vec4 TEX0;
uniform sampler2D Texture;
uniform vec2 TextureSize;

void main()
{
	vec2 uv = TEX0.xy;
	vec2 texel = 1.0 / TextureSize;
	vec3 c = texture2D(Texture, uv).rgb;
	vec3 l = texture2D(Texture, uv - vec2(texel.x, 0.0)).rgb;
	vec3 r = texture2D(Texture, uv + vec2(texel.x, 0.0)).rgb;
	vec3 u = texture2D(Texture, uv - vec2(0.0, texel.y)).rgb;
	vec3 d = texture2D(Texture, uv + vec2(0.0, texel.y)).rgb;
	vec3 blur = (l + r + u + d) * 0.25;
	vec3 sharp = c + (c - blur) * 0.055;
	sharp = clamp((sharp - 0.5) * 1.012 + 0.5, 0.0, 1.0);
	gl_FragColor = vec4(sharp, 1.0);
}
