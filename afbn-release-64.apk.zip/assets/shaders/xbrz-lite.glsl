#ifdef GL_ES
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
#endif

varying vec4 TEX0;
uniform sampler2D Texture;
uniform vec2 TextureSize;

float lum(vec3 c)
{
	return dot(c, vec3(0.299, 0.587, 0.114));
}

vec3 sampleOffset(vec2 uv, vec2 off)
{
	return texture2D(Texture, uv + off / TextureSize).rgb;
}

void main()
{
	vec2 uv = TEX0.xy;
	vec2 f = fract(uv * TextureSize);
	vec3 c = sampleOffset(uv, vec2(0.0));
	vec3 l = sampleOffset(uv, vec2(-1.0, 0.0));
	vec3 r = sampleOffset(uv, vec2( 1.0, 0.0));
	vec3 u = sampleOffset(uv, vec2(0.0, -1.0));
	vec3 d = sampleOffset(uv, vec2(0.0,  1.0));
	vec3 ul = sampleOffset(uv, vec2(-1.0, -1.0));
	vec3 ur = sampleOffset(uv, vec2( 1.0, -1.0));
	vec3 dl = sampleOffset(uv, vec2(-1.0,  1.0));
	vec3 dr = sampleOffset(uv, vec2( 1.0,  1.0));

	float diagA = abs(lum(ul) - lum(dr));
	float diagB = abs(lum(ur) - lum(dl));
	vec3 diag = diagA < diagB ? mix(ul, dr, (f.x + f.y) * 0.5) : mix(dl, ur, (f.x + (1.0 - f.y)) * 0.5);
	vec3 cross = mix(mix(l, r, f.x), mix(u, d, f.y), 0.5);
	float contrast = max(max(abs(lum(l) - lum(r)), abs(lum(u) - lum(d))), abs(diagA - diagB));
	float amount = smoothstep(0.018, 0.18, contrast);
	vec3 result = mix(c, mix(cross, diag, 0.42), amount * 0.38);
	result = result * 1.035 - (l + r + u + d) * 0.00875;
	gl_FragColor = vec4(clamp(result, 0.0, 1.0), 1.0);
}
