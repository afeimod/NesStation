#ifdef GL_ES
precision mediump float;
#endif

varying vec4 TEX0;
uniform sampler2D Texture;
uniform vec2 TextureSize;

void main()
{
	vec2 uv = (floor(TEX0.xy * TextureSize) + 0.5) / TextureSize;
	vec4 color = texture2D(Texture, uv);
	float line = mod(gl_FragCoord.y, 3.0);
	float mask = line < 1.0 ? 0.82 : 1.0;
	gl_FragColor = vec4(color.rgb * mask, color.a);
}
