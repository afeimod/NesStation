#ifdef GL_ES
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
#endif

varying vec4 TEX0;
uniform sampler2D Texture;
uniform vec2 TextureSize;

float lum(vec3 c)
{
	return dot(c, vec3(0.299, 0.587, 0.114));
}

vec3 px(vec2 uv, vec2 o)
{
	return texture2D(Texture, uv + o / TextureSize).rgb;
}

void main()
{
	vec2 uv = TEX0.xy;
	vec3 c  = px(uv, vec2( 0.0,  0.0));
	vec3 l  = px(uv, vec2(-1.0,  0.0));
	vec3 r  = px(uv, vec2( 1.0,  0.0));
	vec3 u  = px(uv, vec2( 0.0, -1.0));
	vec3 d  = px(uv, vec2( 0.0,  1.0));
	vec3 ul = px(uv, vec2(-1.0, -1.0));
	vec3 ur = px(uv, vec2( 1.0, -1.0));
	vec3 dl = px(uv, vec2(-1.0,  1.0));
	vec3 dr = px(uv, vec2( 1.0,  1.0));

	float h = abs(lum(l) - lum(r));
	float v = abs(lum(u) - lum(d));
	float a = abs(lum(ul) - lum(dr));
	float b = abs(lum(ur) - lum(dl));
	vec3 axis = h < v ? (l + r) * 0.5 : (u + d) * 0.5;
	vec3 diag = a < b ? (ul + dr) * 0.5 : (ur + dl) * 0.5;
	float edge = smoothstep(0.014, 0.15, max(abs(h - v), abs(a - b)));
	vec3 blend = mix(axis, diag, 0.45);
	vec3 result = mix(c, blend, edge * 0.38);
	result = result * 1.035 - (l + r + u + d) * 0.00875;
	gl_FragColor = vec4(clamp(result, 0.0, 1.0), 1.0);
}
