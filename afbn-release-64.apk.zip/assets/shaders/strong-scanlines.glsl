#ifdef GL_ES
precision mediump float;
#endif

varying vec4 TEX0;
uniform sampler2D Texture;
uniform vec2 TextureSize;

void main()
{
	vec2 uv = (floor(TEX0.xy * TextureSize) + 0.5) / TextureSize;
	vec4 color = texture2D(Texture, uv);
	float line = mod(gl_FragCoord.y, 4.0);
	float mask = line < 1.25 ? 0.64 : 1.04;
	vec3 boosted = pow(color.rgb, vec3(0.96)) * mask;
	gl_FragColor = vec4(clamp(boosted, 0.0, 1.0), color.a);
}
