//afbn专用高仿街机滤镜，碎总制作，q号：438605942，afbn交流群号：556297887；
//请勿对滤镜进行私自修改，变卖。
#define saturate(c) clamp(c, 0.0, 1.0)
#define lerp(a,b,c) mix(a,b,c)
#define mul(a,b) (b*a)
#define fmod(c,d) mod(c,d)
#define frac(c) fract(c)
#define rsqrt(x)  1.0/sqrt(x)
#define rcp(x)  1.0/x
#define float2 vec2
#define float3 vec3
#define float4 vec4
#define int2 ivec2
#define int3 ivec3
#define int4 ivec4
#define bool2 bvec2
#define bool3 bvec3
#define bool4 bvec4
#define float2x2 mat2x2
#define float3x3 mat3x3
#define float4x4 mat4x4

#if defined(VERTEX)

#if __VERSION__ >= 130
#define COMPAT_VARYING out
#define COMPAT_ATTRIBUTE in
#define COMPAT_TEXTURE texture
#else
#define COMPAT_VARYING varying 
#define COMPAT_ATTRIBUTE attribute 
#define COMPAT_TEXTURE texture2D
#endif

#ifdef GL_ES
#define COMPAT_PRECISION mediump
#else
#define COMPAT_PRECISION
#endif

COMPAT_ATTRIBUTE vec4 VertexCoord;
COMPAT_ATTRIBUTE vec4 COLOR;
COMPAT_ATTRIBUTE vec4 TexCoord;
COMPAT_VARYING vec4 COL0;
COMPAT_VARYING vec4 TEX0;

vec4 _oPosition1; 
uniform mat4 MVPMatrix;
uniform COMPAT_PRECISION int FrameDirection;
uniform COMPAT_PRECISION int FrameCount;
uniform COMPAT_PRECISION vec2 OutputSize;
uniform COMPAT_PRECISION vec2 TextureSize;
uniform COMPAT_PRECISION vec2 InputSize;

void main()
{
    gl_Position = MVPMatrix * VertexCoord;
    COL0 = COLOR;
    TEX0.xy = TexCoord.xy;
}

#elif defined(FRAGMENT)

#if __VERSION__ >= 130
#define COMPAT_VARYING in
#define COMPAT_TEXTURE texture
out vec4 FragColor;
#else
#define COMPAT_VARYING varying
#define FragColor gl_FragColor
#define COMPAT_TEXTURE texture2D
#endif

#ifdef GL_ES
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
precision mediump int;
#endif
#define COMPAT_PRECISION mediump
#else
#define COMPAT_PRECISION
#endif

uniform COMPAT_PRECISION int FrameDirection;
uniform COMPAT_PRECISION int FrameCount;
uniform COMPAT_PRECISION vec2 OutputSize;
uniform COMPAT_PRECISION vec2 TextureSize;
uniform COMPAT_PRECISION vec2 InputSize;
uniform sampler2D Texture;
COMPAT_VARYING vec4 TEX0;
#define SourceSize vec4(TextureSize, 1.0 / TextureSize) 

vec3 ACES_Tonemap_core(vec3 color, float exposure, float contrast) {
	vec3 exposed = color * exposure;

	const mat3 AP0_TO_AP1 = mat3(
		0.597190000000000, 0.076000000000000, 0.028400000000000,
		0.354580000000000, 0.908340000000000, 0.133830000000000,
		0.048230000000000, 0.015660000000000, 0.837770000000000
	);

	vec3 ap1 = AP0_TO_AP1 * exposed;

	const vec3 LUMINANCE_AP1 = vec3(0.27222871678091454, 0.67408176581114831, 0.05368951740793705);
	float luma = dot(ap1, LUMINANCE_AP1);
	float compressed = luma <= 0.002 ? luma * 2.0 : log2(luma * 0.5 + 1.0);

	float sat_factor = 1.0 - 0.4 * clamp(compressed, 0.0, 1.0);
	vec3 adjusted = vec3(compressed) + (ap1 - luma) * sat_factor;

	vec3 a = adjusted * (adjusted + 0.0245786) - 0.000090537;
	vec3 b = adjusted * (0.983729 * adjusted + 0.4329510) + 0.238081;
	vec3 rrt = a / (b + 1e-8);

	const mat3 ACES_OUTPUT = mat3(
		1.604750000000000, -0.102080000000000, -0.003270000000000,
		-0.531080000000000, 1.108130000000000, -0.072760000000000,
		-0.073670000000000, -0.006050000000000, 1.076020000000000
	);

	vec3 outColor = ACES_OUTPUT * rrt;

	vec3 contrast_adj = (outColor - 0.5) * contrast + 0.5;
	outColor = mix(outColor, contrast_adj, vec3(0.5));
	return clamp(outColor, vec3(0.0), vec3(1.0));
}

vec3 ACES_Tonemap(vec3 color, float exposure, float contrast) {
	return ACES_Tonemap_core(color, exposure, contrast);
}

vec3 ACES_Tonemap(vec3 color) {
	return ACES_Tonemap_core(color, 1.0, 1.0);
}

vec3 ACES_GameToneMap(vec3 color) {
	return ACES_Tonemap_core(color * 1.0, 1.0, 1.0);
}

vec4 coolTintFilter(vec3 colorIn) {
	vec4 P = (colorIn.g < colorIn.b) ? vec4(colorIn.bg, -1.0, 2.0/3.0) : vec4(colorIn.gb, 0.0, -1.0/3.0);
	vec4 Q = (colorIn.r < P.x) ? vec4(P.xyw, colorIn.r) : vec4(colorIn.r, P.yzx);
	float C_hcv = Q.x - min(Q.w, Q.y);
	float H_hcv = C_hcv > 0.0001 ? abs((Q.w - Q.y) / (6.0 * C_hcv) + Q.z) : 0.0;
	float V_hcv = Q.x;
	vec3 HCV = vec3(H_hcv, C_hcv, V_hcv);

	float L_olum = HCV.z - HCV.y * 0.5;
    const vec3 kCoolColor = vec3(0.55, 0.70, 1.0);   
    float blendFactor = 0.45;                       
	
	vec3 blended = mix(colorIn, colorIn * kCoolColor, blendFactor);

	vec4 P_blend = (blended.g < blended.b) ? vec4(blended.bg, -1.0, 2.0/3.0) : vec4(blended.gb, 0.0, -1.0/3.0);
	vec4 Q_blend = (blended.r < P_blend.x) ? vec4(P_blend.xyw, blended.r) : vec4(blended.r, P_blend.yzx);
	float C_blend = Q_blend.x - min(Q_blend.w, Q_blend.y);
	float H_blend = C_blend > 0.0001 ? abs((Q_blend.w - Q_blend.y) / (6.0 * C_blend) + Q_blend.z) : 0.0;
	float V_blend = Q_blend.x;
	vec3 HCV_blend = vec3(H_blend, C_blend, V_blend);

	float L_blend = HCV_blend.z - HCV_blend.y * 0.5;
	float S_blend = C_blend > 0.0001 ? HCV_blend.y / (1.0 - abs(L_blend * 2.0 - 1.0)) : 0.0;
	vec3 HSL_blend = vec3(H_blend, S_blend, L_blend);

	float H = HSL_blend.x;
	float S = HSL_blend.y;
	float L = HSL_blend.z;

	float C_hsl = (1.0 - abs(2.0 * L - 1.0)) * S;
	float X = C_hsl * (1.0 - abs(mod(H * 6.0, 2.0) - 1.0));
	float m = L - C_hsl * 0.5;
	vec3 RGB_hue;
	if (H < 1.0/6.0) {
		RGB_hue = vec3(C_hsl, X, 0.0);
	} else if (H < 2.0/6.0) {
		RGB_hue = vec3(X, C_hsl, 0.0);
	} else if (H < 3.0/6.0) {
		RGB_hue = vec3(0.0, C_hsl, X);
	} else if (H < 4.0/6.0) {
		RGB_hue = vec3(0.0, X, C_hsl);
	} else if (H < 5.0/6.0) {
		RGB_hue = vec3(X, 0.0, C_hsl);
	} else {
		RGB_hue = vec3(C_hsl, 0.0, X);
	}

	vec3 finalColor = RGB_hue + vec3(m);

	finalColor = clamp(finalColor, 0.0, 1.0);
	
finalColor.b = min(finalColor.b * 1.10, 1.0);
finalColor.r = finalColor.r * 0.92;
	
	return vec4(finalColor, 1.0);
}


#define iTime (float(FrameCount) / 60.0)
#define PS2_BLACK_LEVEL 0.02      
#define PHOSPHOR_DENSITY 0.4        
#define PHOSPHOR_STRENGTH 0.15      

#define BEAM_GLOW_STRENGTH 0.25     
#define BEAM_GLOW_THRESHOLD 0.3   
#define BEAM_GLOW_RADIUS 0.003     
#define SCANLINE_FLICKER_AMOUNT 0.003
#define SCANLINE_FLICKER_SPEED 0.3
vec3 beam_glow(vec3 color, vec2 uv, float time) {
    vec2 r = vec2(BEAM_GLOW_RADIUS, 0.0);
    vec2 r2 = vec2(BEAM_GLOW_RADIUS * 0.5, BEAM_GLOW_RADIUS * 0.866);
    
    vec3 blur = texture2D(Texture, uv + r).rgb;
    blur += texture2D(Texture, uv - r).rgb;
    blur += texture2D(Texture, uv + vec2(0.0, BEAM_GLOW_RADIUS)).rgb;
    blur += texture2D(Texture, uv - vec2(0.0, BEAM_GLOW_RADIUS)).rgb;
    blur += texture2D(Texture, uv + r2).rgb;
    blur += texture2D(Texture, uv - r2).rgb;
    blur += texture2D(Texture, uv + vec2(-r2.x, r2.y)).rgb;
    blur += texture2D(Texture, uv + vec2(r2.x, -r2.y)).rgb;
    blur /= 8.0;
   
    float lum = dot(color, vec3(0.299, 0.587, 0.114));
    float glow = smoothstep(BEAM_GLOW_THRESHOLD, BEAM_GLOW_THRESHOLD + 0.5, lum) * BEAM_GLOW_STRENGTH;
    
    vec3 glow_main = mix(color, blur, glow);
    
    vec2 r_large = vec2(BEAM_GLOW_RADIUS * 2.5, 0.0);
    vec3 blur_large = texture2D(Texture, uv + r_large).rgb;
    blur_large += texture2D(Texture, uv - r_large).rgb;
    blur_large += texture2D(Texture, uv + vec2(0.0, BEAM_GLOW_RADIUS * 2.5)).rgb;
    blur_large += texture2D(Texture, uv - vec2(0.0, BEAM_GLOW_RADIUS * 2.5)).rgb;
    blur_large /= 4.0;
    
    float glow_edge = glow * 0.4;
    vec3 glow_result = mix(glow_main, blur_large, glow_edge);
    
    return glow_result;
}

vec3 phosphor_dot(vec3 color, vec2 uv) {    
    float base_resolution = 720.0;           
    float screen_height = OutputSize.y;      
    float scale = screen_height / base_resolution;  
    
    float density_scale = 1.0 / max(scale, 0.5);
    vec2 grid = uv * screen_height * PHOSPHOR_DENSITY * density_scale;
    vec2 dot_pos = fract(grid) - 0.5;
    float dot = 1.0 - smoothstep(0.0, 0.3, length(dot_pos));
    
    float lum = dot(color, vec3(0.299, 0.587, 0.114));
    dot = mix(1.0, 1.0 - dot * PHOSPHOR_STRENGTH, smoothstep(0.3, 0.8, lum));
    
    return color * dot;
}

vec3 temp_to_9300K(vec3 color) {
    const mat3 temp_shift = mat3(
        0.98, 0.00, 0.02,
        0.00, 0.98, 0.02,
        0.00, 0.00, 1.02
    );
    vec3 result = temp_shift * color * 1.05;
    
    float yellow_mask = smoothstep(0.3, 0.8, min(result.r, result.g));
    result.r *= 1.0 + 0.08 * yellow_mask;
    result.g *= 1.0 + 0.08 * yellow_mask;
   
    float lum = dot(result, vec3(0.299, 0.587, 0.114));
    float white_boost = 1.0 + 0.06 * smoothstep(0.5, 0.9, lum);  
    result *= white_boost;
    
    return result;
}

#define GAMMA 2.2
#define LINE_PITCH_COEF 1.0
#define LINE_THICKNESS 0.55
#define LINE_OPACITY 0.45
#define LINEAR_X 0.8
#define PIC_SCALE_X 1.0
#define PIC_SCALE_Y 1.0
#define INT_TOL 0.05
#define INT_SCALE 0.0
#define CURVE_X 0.0
#define CURVE_Y 0.0
#define HT_INTENSITY 0.6
float a(vec3 b)
{
    return b.r*0.3 + b.g*0.6 + b.b*0.1;
}

vec3 c(sampler2D Source, vec2 o, vec4 p, vec2 d)
{
    vec2 e = o * p.xy - 0.5;
    vec2 f = fract(e);
    f = clamp((f - 0.5)/d + 0.5, 0.0, 1.0);
    vec2 p00 = floor(e) + 0.5;
    vec2 p10 = p00 + vec2(1.0, 0.0);
    vec2 p01 = p00 + vec2(0.0, 1.0);
    vec2 p11 = p00 + 1.0;
    vec2 g = InputSize / TextureSize;   // InputSize/TextureSize → 1.0
    vec3 c00 = texture2D(Texture, fract(p00 * p.zw * g)).rgb;
    vec3 c10 = texture2D(Texture, fract(p10 * p.zw * g)).rgb;
    vec3 c01 = texture2D(Texture, fract(p01 * p.zw * g)).rgb;
    vec3 c11 = texture2D(Texture, fract(p11 * p.zw * g)).rgb;
    c00 *= c00;
    c10 *= c10;
    c01 *= c01;
    c11 *= c11;
    vec3 colx0 = mix(c00, c10, f.x);
    vec3 colx1 = mix(c01, c11, f.x);
    return sqrt(mix(colx0, colx1, f.y));
}

vec2 h(vec2 r) {
    if (CURVE_X < 0.005 && CURVE_Y < 0.005) return r;
    float rx = 1.0 / clamp(CURVE_X * 2.0, 0.01, 1.0);
    float ry = 1.0 / clamp(CURVE_Y, 0.01, 1.0);
    float s1x = sin(1.0 / rx);
    float s1y = sin(1.0 / ry);
    vec2 uv2 = (r - 0.50001) * 2.0;
    float ux = uv2.x;
    float uy = uv2.y;
    float theta_x = ux / rx;
    float theta_y = uy / ry;
    ux = ux * ux * s1x / sin(theta_x);
    uy = uy * uy * s1y / sin(theta_y);  
    float cos_tx = cos(theta_x);
    float cos_ty = cos(theta_y);
    float j = rx * (1.0 - cos_tx);
    float k = ry * (1.0 - cos_ty);
    float l = 1.0 - k * 0.3;
    ux /= l;
    float m = ux * 0.5 + 0.50001;
    return vec2(m, r.y);
}

vec3 n(vec3 t, float d) {
    t = clamp(t, 0.0, 1.0);
    float p0 = 0.0;
    float p3 = 1.0;
    vec3 u = 1.0 - t;  
    vec3 tt = t * t;   
    vec3 uu = u * u;   
    vec3 uuu = uu * u; 
    vec3 ttt = tt * t; 
    vec3 y = uuu * p0 + 3.0 * uu * t * (0.25+d) + 3.0 * u * tt * 0.75 + ttt * p3;
    return clamp(y, 0.0, 1.0);  
}

vec3 scalin2(vec3 color) 
{
   
    vec4 p = vec4(InputSize, 1.0/InputSize);
    vec4 q = vec4(TextureSize, 1.0/TextureSize);
    float OutputSize_w = 1.0/OutputSize.y;

    vec2 TEX0 = TEX0.xy;                     
    vec4 vParameter;
    vec4 vParameter2;
    vParameter.w = step(q.y+1.0, p.y);
    float multi_y0 = OutputSize.y * q.w;
    float multi_y1 = multi_y0 * PIC_SCALE_Y;
    vParameter2.x = max(floor(multi_y1 * (1.0 + INT_TOL * step(multi_y1, 4.0))), 1.0);
    vParameter.y = multi_y0 / vParameter2.x;
    vParameter.x = INT_SCALE > 0.75 ? multi_y0 / vParameter2.x : 1.0 / PIC_SCALE_X;
    vParameter.zw = (1.0 - 1.0/vParameter.xy) * 0.5;
    vParameter.w = floor(vParameter.w * OutputSize.y) * OutputSize_w;
    vParameter2.z = max(floor(vParameter2.x * LINE_PITCH_COEF + 0.5), 3.0);
    vParameter2.w = step(q.y+1.0, p.y);

    float delta[5];
    delta[0] = 0.21;
    delta[1] = 0.15;
    delta[2] = 0.13;
    delta[3] = 0.12;
    delta[4] = 0.1;  
    vec2 g = InputSize / TextureSize;         
    vec2 o = TEX0.xy / g;                     

    vec2 r = h(o);
   r -= vec2(0.0); 
    float s = floor(r.y * OutputSize.y) + 0.5;
    r *= vec2(1.0, 1.0); 
    vec2 t = vec2(LINEAR_X, vParameter2.w);
    vec2 u = vec2(0.0);
    if (p.x * q.z > 1.5) {
        vec3 v = texture2D(Texture, (r - vec2(q.z*0.45, 0.0)) * g).rgb;
        vec3 w = texture2D(Texture, (r + vec2(q.z*0.45, 0.0)) * g).rgb;
        #define www (a(v) - a(w))
        u.x = www * 0.25 * q.z;
        u.x *= LINEAR_X;
        t.x = 1.0;
    }
    vec3 x = c(Texture, r - u, p, t);
    vec3 y = x;
    x = pow(x, vec3(GAMMA * 0.5));
    if (vParameter2.x * LINE_PITCH_COEF > 2.9) {
        #define zzz vParameter2.z
        y = n(y, delta[int(min(zzz, 7.0)) - 3]);
        y = pow(y, vec3(GAMMA));
        vec3 aa = (y * HT_INTENSITY + (1.0 - HT_INTENSITY)) * zzz;
        aa *= LINE_THICKNESS;
        float bb = mod(s, zzz) - zzz * 0.5;
        vec3 cc;
        cc.rb = vec2(abs(bb * 2.0 - 0.5));
        cc.g = abs(-bb * 2.0 - 0.5);
        vec3 dd = clamp((aa - cc + 0.5), 0.0, 1.0);
        dd *= y / (y * HT_INTENSITY + 1.0 - HT_INTENSITY);
        dd = sqrt(dd);
        color.rgb = mix(x, dd, LINE_OPACITY);
    }
    else{
        color.rgb = x;
        }
        color.rgb = beam_glow(color.rgb, TEX0.xy, iTime);    
    color.rgb = max(color.rgb - PS2_BLACK_LEVEL, 0.0);    
    color.rgb = phosphor_dot(color.rgb, TEX0.xy);
        float line_flicker = 1.0 + SCANLINE_FLICKER_AMOUNT * sin(iTime * 3.14159 * SCANLINE_FLICKER_SPEED + s * 3.14159);
        color.rgb *= line_flicker;
color.rgb = temp_to_9300K(color.rgb);
   
float lum = dot(color.rgb, vec3(0.299, 0.587, 0.114));
float highlight_boost = 1.0 + 0.12 * smoothstep(0.4, 0.9, lum);
color.rgb *= highlight_boost;
color.rgb *= 1.00;   

    #define SATURATION_BOOST 1.05
    float lum_sat = dot(color.rgb, vec3(0.299, 0.587, 0.114));
    color.rgb = mix(vec3(lum_sat), color.rgb, SATURATION_BOOST);

    #define BRIGHTNESS_BOOST 1.1       
    color.rgb *= BRIGHTNESS_BOOST;


    return color;

}

vec3 Contrast_Adaptive_Sharpening(float Sharpening, vec3 Color) {
    
	vec3 b = texture2D(Texture, TEX0.xy+ vec2(0.0, -1.0) * TextureSize).xyz;
	vec3 d = texture2D(Texture, TEX0.xy + vec2(-1.0, 0.0) * TextureSize).xyz;
	vec3 e = texture2D(Texture, TEX0.xy).rgb; 
	vec3 f = texture2D(Texture, TEX0.xy + vec2(1.0, 0.0) * TextureSize).xyz;
	vec3 h = texture2D(Texture, TEX0.xy + vec2(0.0, 1.0) * TextureSize).rgb;

	float bR = b.r;
	float bG = b.g;
	float bB = b.b;
	float dR = d.r;
	float dG = d.g;
	float dB = d.b;
	float eR = e.r;
	float eG = e.g;
	float eB = e.b;
	float fR = f.r;
	float fG = f.g;
	float fB = f.b;
	float hR = h.r;
	float hG = h.g;
	float hB = h.b;
	float nz;

	float bL = 0.299 * bR + 0.587 * bG + 0.114 * bB;
	float dL = 0.299 * dR + 0.587 * dG + 0.114 * dB;
	float eL = 0.299 * eR + 0.587 * eG + 0.114 * eB;
	float fL = 0.299 * fR + 0.587 * fG + 0.114 * fB;
	float hL = 0.299 * hR + 0.587 * hG + 0.114 * hB;

	nz = 0.25 * bL + 0.25 * dL + 0.25 * fL + 0.25 * hL - eL;
	float brightnessRange = max(max(bL, max(dL, eL)), max(fL, hL)) - min(min(bL, min(dL, eL)), min(fL, hL));
	nz = clamp((abs(nz) * 1.0 / (brightnessRange + 1e-6)), 0.0, 1.0);
	nz = -0.5 * nz + 1.0;

	float mn4R = min(min(bR, min(dR, fR)), hR);
	float mn4G = min(min(bG, min(dG, fG)), hG);
	float mn4B = min(min(bB, min(dB, fB)), hB);
	float mx4R = max(max(bR, max(dR, fR)), hR);
	float mx4G = max(max(bG, max(dG, fG)), hG);
	float mx4B = max(max(bB, max(dB, fB)), hB);

	float deltaMinR = eR - mn4R;
	float deltaMaxR = mx4R - eR;
	float deltaMinG = eG - mn4G;
	float deltaMaxG = mx4G - eG;
	float deltaMinB = eB - mn4B;
	float deltaMaxB = mx4B - eB;

	float rangeR = mx4R - mn4R + 1e-6;
	float rangeG = mx4G - mn4G + 1e-6;
	float rangeB = mx4B - mn4B + 1e-6;

	float hitMinR = clamp(deltaMinR / (4.0 * rangeR), 0.0, 1.0);
	float hitMinG = clamp(deltaMinG / (4.0 * rangeG), 0.0, 1.0);
	float hitMinB = clamp(deltaMinB / (4.0 * rangeB), 0.0, 1.0);
	float hitMaxR = clamp(deltaMaxR / (4.0 * rangeR), 0.0, 1.0);
	float hitMaxG = clamp(deltaMaxG / (4.0 * rangeG), 0.0, 1.0);
	float hitMaxB = clamp(deltaMaxB / (4.0 * rangeB), 0.0, 1.0);

	float lobeR = min(hitMinR, hitMaxR);
	float lobeG = min(hitMinG, hitMaxG);
	float lobeB = min(hitMinB, hitMaxB);
	float lobe = max(-(0.25 - (1.0 / 16.0)), min(max(lobeR, max(lobeG, lobeB)), 0.0)) * Sharpening;

	lobe *= nz;

	float rcpL = 1.0 / (4.0 * lobe + 1.0);
	Color = vec3(
	(lobe * bR + lobe * dR + lobe * hR + lobe * fR + eR) * rcpL,
	(lobe * bG + lobe * dG + lobe * hG + lobe * fG + eG) * rcpL,
	(lobe * bB + lobe * dB + lobe * hB + lobe * fB + eB) * rcpL
	);

	return Color;
}

void main()
{   
    vec3 color = texture2D(Texture, TEX0.xy).rgb;   
    color = Contrast_Adaptive_Sharpening(0.8, color);
          color = scalin2(color);
          
          
    color = coolTintFilter(color.xyz).rgb;
	vec3 white_mapped = ACES_Tonemap_core(vec3(1.0), 1.0, 1.0);
	vec3 mapped = ACES_GameToneMap(color.rgb) / (white_mapped + 1e-8);

	float lift = 0.25;
	color = mapped * (1.0 + lift) / (1.0 + mapped * lift);

#define CHROMA_SCALE 0.85

float Y  = dot(color.rgb, vec3(0.2126, 0.7152, 0.0722));
float Cb = (color.b - Y) / 1.8556;
float Cr = (color.r - Y) / 1.5748;

Cb *= CHROMA_SCALE;
Cr *= CHROMA_SCALE;

color.r = Y + 1.5748 * Cr;
color.b = Y + 1.8556 * Cb;
color.g = Y - 0.1873 * Cb - 0.4681 * Cr;
color = clamp(color, 0.0, 1.0);

  
   gl_FragColor = vec4(clamp(color, 0.0, 1.0), 1.0);

}
#endif