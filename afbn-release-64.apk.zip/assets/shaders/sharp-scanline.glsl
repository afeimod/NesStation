#ifdef GL_ES
precision mediump float;
#endif

varying vec4 TEX0;
uniform sampler2D Texture;
uniform vec2 TextureSize;

void main()
{
	vec2 uv = (floor(TEX0.xy * TextureSize) + 0.5) / TextureSize;
	vec3 c = texture2D(Texture, uv).rgb;
	float line = step(0.35, fract(gl_FragCoord.y * 0.5));
	float scan = mix(0.72, 1.08, line);
	c = clamp((c - 0.5) * 1.08 + 0.5, 0.0, 1.0) * scan;
	gl_FragColor = vec4(clamp(c, 0.0, 1.0), 1.0);
}
