#ifdef GL_ES
precision mediump float;
#endif

varying vec4 TEX0;
uniform sampler2D Texture;
uniform vec2 TextureSize;

void main()
{
	vec2 uv = (floor(TEX0.xy * TextureSize) + 0.5) / TextureSize;
	vec3 c = texture2D(Texture, uv).rgb;
	c = floor(c * 7.0 + 0.5) / 7.0;
	c = pow(c, vec3(0.82));
	gl_FragColor = vec4(clamp(c * 1.08, 0.0, 1.0), 1.0);
}
