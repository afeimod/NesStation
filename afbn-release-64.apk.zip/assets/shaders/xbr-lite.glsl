#ifdef GL_ES
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
#endif

varying vec4 TEX0;
uniform sampler2D Texture;
uniform vec2 TextureSize;

float lum(vec3 c)
{
	return dot(c, vec3(0.299, 0.587, 0.114));
}

vec3 tap(vec2 uv, vec2 o)
{
	return texture2D(Texture, uv + o / TextureSize).rgb;
}

void main()
{
	vec2 uv = TEX0.xy;
	vec3 c  = tap(uv, vec2( 0.0,  0.0));
	vec3 l  = tap(uv, vec2(-1.0,  0.0));
	vec3 r  = tap(uv, vec2( 1.0,  0.0));
	vec3 u  = tap(uv, vec2( 0.0, -1.0));
	vec3 d  = tap(uv, vec2( 0.0,  1.0));
	vec3 ul = tap(uv, vec2(-1.0, -1.0));
	vec3 ur = tap(uv, vec2( 1.0, -1.0));
	vec3 dl = tap(uv, vec2(-1.0,  1.0));
	vec3 dr = tap(uv, vec2( 1.0,  1.0));

	float e1 = abs(lum(ul) - lum(dr)) + abs(lum(l) - lum(d)) + abs(lum(u) - lum(r));
	float e2 = abs(lum(ur) - lum(dl)) + abs(lum(r) - lum(d)) + abs(lum(u) - lum(l));
	vec3 diag = e1 < e2 ? (ul + dr) * 0.5 : (ur + dl) * 0.5;
	float edge = smoothstep(0.018, 0.16, abs(e1 - e2));
	vec3 cross = (l + r + u + d) * 0.25;
	vec3 smooth = mix(cross, diag, edge);
	vec3 result = mix(c, smooth, edge * 0.34);
	result = result * 1.045 - (l + r + u + d) * 0.011;
	gl_FragColor = vec4(clamp(result, 0.0, 1.0), 1.0);
}
