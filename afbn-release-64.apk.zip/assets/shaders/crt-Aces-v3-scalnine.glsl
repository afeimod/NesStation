//afbn专用高仿街机滤镜，碎总制作，q号：438605942，afbn交流群号：556297887；
//请勿对滤镜进行私自修改，变卖。
#define saturate(c) clamp(c, 0.0, 1.0)
#define lerp(a,b,c) mix(a,b,c)
#define mul(a,b) (b*a)
#define fmod(c,d) mod(c,d)
#define frac(c) fract(c)
#define rsqrt(x)  1.0/sqrt(x)
#define rcp(x)  1.0/x
#define float2 vec2
#define float3 vec3
#define float4 vec4
#define int2 ivec2
#define int3 ivec3
#define int4 ivec4
#define bool2 bvec2
#define bool3 bvec3
#define bool4 bvec4
#define float2x2 mat2x2
#define float3x3 mat3x3
#define float4x4 mat4x4

#if defined(VERTEX)

#if __VERSION__ >= 130
#define COMPAT_VARYING out
#define COMPAT_ATTRIBUTE in
#define COMPAT_TEXTURE texture
#else
#define COMPAT_VARYING varying 
#define COMPAT_ATTRIBUTE attribute 
#define COMPAT_TEXTURE texture2D
#endif

#ifdef GL_ES
#define COMPAT_PRECISION mediump
#else
#define COMPAT_PRECISION
#endif

COMPAT_ATTRIBUTE vec4 VertexCoord;
COMPAT_ATTRIBUTE vec4 COLOR;
COMPAT_ATTRIBUTE vec4 TexCoord;
COMPAT_VARYING vec4 COL0;
COMPAT_VARYING vec4 TEX0;

vec4 _oPosition1; 
uniform mat4 MVPMatrix;
uniform COMPAT_PRECISION int FrameDirection;
uniform COMPAT_PRECISION int FrameCount;
uniform COMPAT_PRECISION vec2 OutputSize;
uniform COMPAT_PRECISION vec2 TextureSize;
uniform COMPAT_PRECISION vec2 InputSize;

void main()
{
    gl_Position = MVPMatrix * VertexCoord;
    COL0 = COLOR;
    TEX0.xy = TexCoord.xy;
}

#elif defined(FRAGMENT)

#if __VERSION__ >= 130
#define COMPAT_VARYING in
#define COMPAT_TEXTURE texture
out vec4 FragColor;
#else
#define COMPAT_VARYING varying
#define FragColor gl_FragColor
#define COMPAT_TEXTURE texture2D
#endif

#ifdef GL_ES
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
precision mediump int;
#endif
#define COMPAT_PRECISION mediump
#else
#define COMPAT_PRECISION
#endif

uniform COMPAT_PRECISION int FrameDirection;
uniform COMPAT_PRECISION int FrameCount;
uniform COMPAT_PRECISION vec2 OutputSize;
uniform COMPAT_PRECISION vec2 TextureSize;
uniform COMPAT_PRECISION vec2 InputSize;
uniform sampler2D Texture;
COMPAT_VARYING vec4 TEX0;
#define SourceSize vec4(TextureSize, 1.0 / TextureSize) 

vec3 ACES_Tonemap_core(vec3 color, float exposure, float contrast) {
	vec3 exposed = color * exposure;

	const mat3 AP0_TO_AP1 = mat3(
		0.597190000000000, 0.076000000000000, 0.028400000000000,
		0.354580000000000, 0.908340000000000, 0.133830000000000,
		0.048230000000000, 0.015660000000000, 0.837770000000000
	);

	vec3 ap1 = AP0_TO_AP1 * exposed;

	const vec3 LUMINANCE_AP1 = vec3(0.27222871678091454, 0.67408176581114831, 0.05368951740793705);
	float luma = dot(ap1, LUMINANCE_AP1);
	float compressed = luma <= 0.002 ? luma * 2.0 : log2(luma * 0.5 + 1.0);

	float sat_factor = 1.0 - 0.4 * clamp(compressed, 0.0, 1.0);
	vec3 adjusted = vec3(compressed) + (ap1 - luma) * sat_factor;

	vec3 a = adjusted * (adjusted + 0.0245786) - 0.000090537;
	vec3 b = adjusted * (0.983729 * adjusted + 0.4329510) + 0.238081;
	vec3 rrt = a / (b + 1e-8);

	const mat3 ACES_OUTPUT = mat3(
		1.604750000000000, -0.102080000000000, -0.003270000000000,
		-0.531080000000000, 1.108130000000000, -0.072760000000000,
		-0.073670000000000, -0.006050000000000, 1.076020000000000
	);

	vec3 outColor = ACES_OUTPUT * rrt;

	vec3 contrast_adj = (outColor - 0.5) * contrast + 0.5;
	outColor = mix(outColor, contrast_adj, vec3(0.5));
	return clamp(outColor, vec3(0.0), vec3(1.0));
}

vec3 ACES_Tonemap(vec3 color, float exposure, float contrast) {
	return ACES_Tonemap_core(color, exposure, contrast);
}

vec3 ACES_Tonemap(vec3 color) {
	return ACES_Tonemap_core(color, 1.0, 1.0);
}

vec3 ACES_GameToneMap(vec3 color) {
	return ACES_Tonemap_core(color * 1.0, 1.0, 1.0);
}

vec4 coolTintFilter(vec3 colorIn) {
	vec4 P = (colorIn.g < colorIn.b) ? vec4(colorIn.bg, -1.0, 2.0/3.0) : vec4(colorIn.gb, 0.0, -1.0/3.0);
	vec4 Q = (colorIn.r < P.x) ? vec4(P.xyw, colorIn.r) : vec4(colorIn.r, P.yzx);
	float C_hcv = Q.x - min(Q.w, Q.y);
	float H_hcv = C_hcv > 0.0001 ? abs((Q.w - Q.y) / (6.0 * C_hcv) + Q.z) : 0.0;
	float V_hcv = Q.x;
	vec3 HCV = vec3(H_hcv, C_hcv, V_hcv);

	float L_olum = HCV.z - HCV.y * 0.5;
    const vec3 kCoolColor = vec3(0.55, 0.70, 1.0);   
    float blendFactor = 0.45;                       
	
	vec3 blended = mix(colorIn, colorIn * kCoolColor, blendFactor);

	vec4 P_blend = (blended.g < blended.b) ? vec4(blended.bg, -1.0, 2.0/3.0) : vec4(blended.gb, 0.0, -1.0/3.0);
	vec4 Q_blend = (blended.r < P_blend.x) ? vec4(P_blend.xyw, blended.r) : vec4(blended.r, P_blend.yzx);
	float C_blend = Q_blend.x - min(Q_blend.w, Q_blend.y);
	float H_blend = C_blend > 0.0001 ? abs((Q_blend.w - Q_blend.y) / (6.0 * C_blend) + Q_blend.z) : 0.0;
	float V_blend = Q_blend.x;
	vec3 HCV_blend = vec3(H_blend, C_blend, V_blend);

	float L_blend = HCV_blend.z - HCV_blend.y * 0.5;
	float S_blend = C_blend > 0.0001 ? HCV_blend.y / (1.0 - abs(L_blend * 2.0 - 1.0)) : 0.0;
	vec3 HSL_blend = vec3(H_blend, S_blend, L_blend);

	float H = HSL_blend.x;
	float S = HSL_blend.y;
	float L = HSL_blend.z;

	float C_hsl = (1.0 - abs(2.0 * L - 1.0)) * S;
	float X = C_hsl * (1.0 - abs(mod(H * 6.0, 2.0) - 1.0));
	float m = L - C_hsl * 0.5;
	vec3 RGB_hue;
	if (H < 1.0/6.0) {
		RGB_hue = vec3(C_hsl, X, 0.0);
	} else if (H < 2.0/6.0) {
		RGB_hue = vec3(X, C_hsl, 0.0);
	} else if (H < 3.0/6.0) {
		RGB_hue = vec3(0.0, C_hsl, X);
	} else if (H < 4.0/6.0) {
		RGB_hue = vec3(0.0, X, C_hsl);
	} else if (H < 5.0/6.0) {
		RGB_hue = vec3(X, 0.0, C_hsl);
	} else {
		RGB_hue = vec3(C_hsl, 0.0, X);
	}

	vec3 finalColor = RGB_hue + vec3(m);

	finalColor = clamp(finalColor, 0.0, 1.0);
	
finalColor.b = min(finalColor.b * 1.10, 1.0);
finalColor.r = finalColor.r * 0.92;
	
	return vec4(finalColor, 1.0);
}

#define PS2_SCANLINE_DENSITY 0.500
#define PS2_COLOR_SHIFT 0.0008
#define PS2_BRIGHTNESS_SCALE 0.92
#define PS2_ROLLBAR_SPEED 0.2
#define PS2_ROLLBAR_INTENSITY 0.2
#define iTime (float(FrameCount) / 60.0)
#define PS2_BLACK_LEVEL 0.02      
#define PHOSPHOR_DENSITY 0.4        
#define PHOSPHOR_STRENGTH 0.15      

#define BEAM_GLOW_STRENGTH 0.25     
#define BEAM_GLOW_THRESHOLD 0.3   
#define BEAM_GLOW_RADIUS 0.003     

vec3 beam_glow(vec3 color, vec2 uv, float time) {
    vec2 r = vec2(BEAM_GLOW_RADIUS, 0.0);
    vec2 r2 = vec2(BEAM_GLOW_RADIUS * 0.5, BEAM_GLOW_RADIUS * 0.866);
    
    vec3 blur = texture2D(Texture, uv + r).rgb;
    blur += texture2D(Texture, uv - r).rgb;
    blur += texture2D(Texture, uv + vec2(0.0, BEAM_GLOW_RADIUS)).rgb;
    blur += texture2D(Texture, uv - vec2(0.0, BEAM_GLOW_RADIUS)).rgb;
    blur += texture2D(Texture, uv + r2).rgb;
    blur += texture2D(Texture, uv - r2).rgb;
    blur += texture2D(Texture, uv + vec2(-r2.x, r2.y)).rgb;
    blur += texture2D(Texture, uv + vec2(r2.x, -r2.y)).rgb;
    blur /= 8.0;
   
    float lum = dot(color, vec3(0.299, 0.587, 0.114));
    float glow = smoothstep(BEAM_GLOW_THRESHOLD, BEAM_GLOW_THRESHOLD + 0.5, lum) * BEAM_GLOW_STRENGTH;
    
    vec3 glow_main = mix(color, blur, glow);
    
    vec2 r_large = vec2(BEAM_GLOW_RADIUS * 2.5, 0.0);
    vec3 blur_large = texture2D(Texture, uv + r_large).rgb;
    blur_large += texture2D(Texture, uv - r_large).rgb;
    blur_large += texture2D(Texture, uv + vec2(0.0, BEAM_GLOW_RADIUS * 2.5)).rgb;
    blur_large += texture2D(Texture, uv - vec2(0.0, BEAM_GLOW_RADIUS * 2.5)).rgb;
    blur_large /= 4.0;
    
    float glow_edge = glow * 0.4;
    vec3 glow_result = mix(glow_main, blur_large, glow_edge);
    
    return glow_result;
}

vec3 phosphor_dot(vec3 color, vec2 uv) {
    vec2 grid = uv * 720.0 * PHOSPHOR_DENSITY;
    vec2 dot_pos = fract(grid) - 0.5;
    float dot = 1.0 - smoothstep(0.0, 0.3, length(dot_pos));
    
    float lum = dot(color, vec3(0.299, 0.587, 0.114));
    dot = mix(1.0, 1.0 - dot * PHOSPHOR_STRENGTH, smoothstep(0.3, 0.8, lum));
    
    return color * dot;
}

vec3 temp_to_9300K(vec3 color) {

    const mat3 temp_shift = mat3(
        0.98, 0.00, 0.02,
        0.00, 0.98, 0.02,
        0.00, 0.00, 1.02
    );
    return temp_shift * color * 1.05;
}

vec3 ntscrgb_2_xyz(vec3 c) {
    vec3 v = vec3(pow(c.r, 2.2), pow(c.g, 2.2), pow(c.b, 2.2));
    return v * mat3(
        0.6068909, 0.1735011, 0.2003480,
        0.2989164, 0.5865990, 0.1144845,
        0.0000000, 0.0660957, 1.1162243
    );
}

vec3 xyz_2_srgb(vec3 c) {
    vec3 v = c * mat3(
        3.2404542, -1.5371385, -0.4985314,
        -0.9692660,  1.8760108,  0.0415560,
        0.0556434, -0.2040259,  1.0572252
    );
    
    v.r = (v.r > 0.0031308) ? (1.055 * pow(v.r, 1.0/2.4) - 0.055) : 12.92 * v.r;
    v.g = (v.g > 0.0031308) ? (1.055 * pow(v.g, 1.0/2.4) - 0.055) : 12.92 * v.g;
    v.b = (v.b > 0.0031308) ? (1.055 * pow(v.b, 1.0/2.4) - 0.055) : 12.92 * v.b;
    return v;
}
vec3 ntscrgb_2_srgb(vec3 c) {
    vec3 result = xyz_2_srgb(ntscrgb_2_xyz(c));
    
    float lum = dot(result, vec3(0.299, 0.587, 0.114));
    result.r = lum + (result.r - lum) * 0.96;
    result.g *= 1.02;
    
    return result;
}


vec3 SCANLINE(vec3 color) {
   
    float vUv = fract(TEX0.y + iTime * 0.3);
    int vPos = int(vUv * 720.0 * PS2_SCANLINE_DENSITY);
    float line_intensity = mod(float(vPos), 2.0);
    float off = line_intensity * 0.0005;
    vec2 shift = vec2(off, 0.0);
 
    vec2 colorShiftR = vec2(PS2_COLOR_SHIFT, 0.001);
    vec2 colorShiftG = vec2(-PS2_COLOR_SHIFT * 0.8, 0.0005);
    float r = texture2D(Texture, TEX0.xy + colorShiftR + shift).r;
    float g = texture2D(Texture, TEX0.xy + colorShiftG + shift).g;
    float b = texture2D(Texture, TEX0.xy - vec2(PS2_COLOR_SHIFT * 0.5, 0.0) + shift).b;

    vec4 color = vec4(r, g, b, 1.0) * PS2_BRIGHTNESS_SCALE;
    color *= clamp(line_intensity, 0.85, 1.0);
    

float phase = fract(TEX0.y + iTime * 0.5);
float rollbar = smoothstep(0.82, 1.0, 1.0 - 2.0 * abs(phase - 0.5)) * 0.006;
color.rgb -= rollbar;  
    
    color.rgb = beam_glow(color.rgb, TEX0.xy, iTime);
    
    color.rgb = max(color.rgb - PS2_BLACK_LEVEL, 0.0);
    
    color.rgb = phosphor_dot(color.rgb, TEX0.xy);

    #define SCANLINE_FLICKER_AMOUNT 0.003
    #define SCANLINE_FLICKER_SPEED 0.3
    float line_flicker = 1.0 + SCANLINE_FLICKER_AMOUNT * sin(iTime * 3.14159 * SCANLINE_FLICKER_SPEED + float(vPos) * 3.14159);
    color.rgb *= line_flicker;    
    
    color.rgb = temp_to_9300K(color.rgb);
    color.rgb = ntscrgb_2_srgb(color.rgb);
    
    color.rgb = pow(color.rgb, vec3(0.92));


// 在 color *= 1.03; 之前
float lum = dot(color.rgb, vec3(0.299, 0.587, 0.114));
float highlight_boost = 1.0 + 0.08 * smoothstep(0.4, 0.9, lum);
color.rgb *= highlight_boost;
color.rgb *= 1.03;

    FragColor = clamp(color, 0.0, 1.0);

    return FragColor.xyz;
}

vec3 Contrast_Adaptive_Sharpening(float Sharpening, vec3 Color) {
    
	vec3 b = texture2D(Texture, TEX0.xy+ vec2(0.0, -1.0) * TextureSize).xyz;
	vec3 d = texture2D(Texture, TEX0.xy + vec2(-1.0, 0.0) * TextureSize).xyz;
	vec3 e = texture2D(Texture, TEX0.xy).rgb; 
	vec3 f = texture2D(Texture, TEX0.xy + vec2(1.0, 0.0) * TextureSize).xyz;
	vec3 h = texture2D(Texture, TEX0.xy + vec2(0.0, 1.0) * TextureSize).rgb;

	float bR = b.r;
	float bG = b.g;
	float bB = b.b;
	float dR = d.r;
	float dG = d.g;
	float dB = d.b;
	float eR = e.r;
	float eG = e.g;
	float eB = e.b;
	float fR = f.r;
	float fG = f.g;
	float fB = f.b;
	float hR = h.r;
	float hG = h.g;
	float hB = h.b;
	float nz;

	float bL = 0.299 * bR + 0.587 * bG + 0.114 * bB;
	float dL = 0.299 * dR + 0.587 * dG + 0.114 * dB;
	float eL = 0.299 * eR + 0.587 * eG + 0.114 * eB;
	float fL = 0.299 * fR + 0.587 * fG + 0.114 * fB;
	float hL = 0.299 * hR + 0.587 * hG + 0.114 * hB;

	nz = 0.25 * bL + 0.25 * dL + 0.25 * fL + 0.25 * hL - eL;
	float brightnessRange = max(max(bL, max(dL, eL)), max(fL, hL)) - min(min(bL, min(dL, eL)), min(fL, hL));
	nz = clamp((abs(nz) * 1.0 / (brightnessRange + 1e-6)), 0.0, 1.0);
	nz = -0.5 * nz + 1.0;

	float mn4R = min(min(bR, min(dR, fR)), hR);
	float mn4G = min(min(bG, min(dG, fG)), hG);
	float mn4B = min(min(bB, min(dB, fB)), hB);
	float mx4R = max(max(bR, max(dR, fR)), hR);
	float mx4G = max(max(bG, max(dG, fG)), hG);
	float mx4B = max(max(bB, max(dB, fB)), hB);

	float deltaMinR = eR - mn4R;
	float deltaMaxR = mx4R - eR;
	float deltaMinG = eG - mn4G;
	float deltaMaxG = mx4G - eG;
	float deltaMinB = eB - mn4B;
	float deltaMaxB = mx4B - eB;

	float rangeR = mx4R - mn4R + 1e-6;
	float rangeG = mx4G - mn4G + 1e-6;
	float rangeB = mx4B - mn4B + 1e-6;

	float hitMinR = clamp(deltaMinR / (4.0 * rangeR), 0.0, 1.0);
	float hitMinG = clamp(deltaMinG / (4.0 * rangeG), 0.0, 1.0);
	float hitMinB = clamp(deltaMinB / (4.0 * rangeB), 0.0, 1.0);
	float hitMaxR = clamp(deltaMaxR / (4.0 * rangeR), 0.0, 1.0);
	float hitMaxG = clamp(deltaMaxG / (4.0 * rangeG), 0.0, 1.0);
	float hitMaxB = clamp(deltaMaxB / (4.0 * rangeB), 0.0, 1.0);

	float lobeR = min(hitMinR, hitMaxR);
	float lobeG = min(hitMinG, hitMaxG);
	float lobeB = min(hitMinB, hitMaxB);
	float lobe = max(-(0.25 - (1.0 / 16.0)), min(max(lobeR, max(lobeG, lobeB)), 0.0)) * Sharpening;

	lobe *= nz;

	float rcpL = 1.0 / (4.0 * lobe + 1.0);
	Color = vec3(
	(lobe * bR + lobe * dR + lobe * hR + lobe * fR + eR) * rcpL,
	(lobe * bG + lobe * dG + lobe * hG + lobe * fG + eG) * rcpL,
	(lobe * bB + lobe * dB + lobe * hB + lobe * fB + eB) * rcpL
	);

	return Color;
}

void main()
{   
    vec3 color = texture2D(Texture, TEX0.xy).rgb;   
    color = Contrast_Adaptive_Sharpening(0.8, color);
          color = SCANLINE(color);
    color = coolTintFilter(color.xyz).rgb;
	vec3 white_mapped = ACES_Tonemap_core(vec3(1.0), 1.0, 1.0);
	vec3 mapped = ACES_GameToneMap(color.rgb) / (white_mapped + 1e-8);

	float lift = 0.25;
	color = mapped * (1.0 + lift) / (1.0 + mapped * lift);

#define CHROMA_SCALE 0.85

float Y  = dot(color.rgb, vec3(0.2126, 0.7152, 0.0722));
float Cb = (color.b - Y) / 1.8556;
float Cr = (color.r - Y) / 1.5748;

Cb *= CHROMA_SCALE;
Cr *= CHROMA_SCALE;

color.r = Y + 1.5748 * Cr;
color.b = Y + 1.8556 * Cb;
color.g = Y - 0.1873 * Cb - 0.4681 * Cr;
color = clamp(color, 0.0, 1.0);

  
   gl_FragColor = vec4(clamp(color, 0.0, 1.0), 1.0);

}
#endif