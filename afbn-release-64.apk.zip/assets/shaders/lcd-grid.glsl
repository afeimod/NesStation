#ifdef GL_ES
precision mediump float;
#endif

varying vec4 TEX0;
uniform sampler2D Texture;

void main()
{
	vec4 color = texture2D(Texture, TEX0.xy);
	float column = mod(gl_FragCoord.x, 3.0);
	float row = mod(gl_FragCoord.y, 3.0);
	vec3 mask = vec3(0.72);
	if (column < 1.0) {
		mask.r = 1.18;
	} else if (column < 2.0) {
		mask.g = 1.18;
	} else {
		mask.b = 1.18;
	}
	if (row < 1.0) mask *= 0.68;
	gl_FragColor = vec4(clamp(color.rgb * mask, 0.0, 1.0), color.a);
}
