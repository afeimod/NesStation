#ifdef GL_ES
precision mediump float;
#endif

varying vec4 TEX0;
uniform sampler2D Texture;
uniform vec2 TextureSize;

void main()
{
	vec2 texel = 1.0 / TextureSize;
	vec3 color = texture2D(Texture, TEX0.xy).rgb * 0.50;
	color += texture2D(Texture, TEX0.xy - vec2(texel.x, 0.0)).rgb * 0.125;
	color += texture2D(Texture, TEX0.xy + vec2(texel.x, 0.0)).rgb * 0.125;
	color += texture2D(Texture, TEX0.xy - vec2(0.0, texel.y)).rgb * 0.125;
	color += texture2D(Texture, TEX0.xy + vec2(0.0, texel.y)).rgb * 0.125;
	gl_FragColor = vec4(color, 1.0);
}
