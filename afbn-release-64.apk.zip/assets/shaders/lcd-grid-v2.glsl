#ifdef GL_ES
precision mediump float;
#endif

varying vec4 TEX0;
uniform sampler2D Texture;

void main()
{
	vec3 color = texture2D(Texture, TEX0.xy).rgb;
	vec2 cell = mod(gl_FragCoord.xy, 3.0);
	vec3 mask = vec3(0.70);
	if (cell.x < 1.0) mask.r = 1.20;
	else if (cell.x < 2.0) mask.g = 1.20;
	else mask.b = 1.20;
	if (cell.y < 1.0) mask *= 0.72;
	color = pow(color * mask, vec3(0.96));
	gl_FragColor = vec4(clamp(color, 0.0, 1.0), 1.0);
}
