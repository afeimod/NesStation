#ifdef GL_ES
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
#endif

varying vec4 TEX0;
uniform sampler2D Texture;
uniform vec2 TextureSize;

void main()
{
	vec2 pos = TEX0.xy * TextureSize - 0.5;
	vec2 base = floor(pos) + 0.5;
	vec2 f = pos - floor(pos);
	vec2 sharp = smoothstep(0.06, 0.94, f);
	vec2 uv = (base + sharp - 0.5) / TextureSize;
	vec3 c = texture2D(Texture, uv).rgb;
	vec3 n = texture2D(Texture, TEX0.xy + vec2( 0.0, -1.0) / TextureSize).rgb;
	vec3 s = texture2D(Texture, TEX0.xy + vec2( 0.0,  1.0) / TextureSize).rgb;
	vec3 e = texture2D(Texture, TEX0.xy + vec2( 1.0,  0.0) / TextureSize).rgb;
	vec3 w = texture2D(Texture, TEX0.xy + vec2(-1.0,  0.0) / TextureSize).rgb;
	c = c * 1.035 - (n + s + e + w) * 0.00875;
	gl_FragColor = vec4(clamp(c, 0.0, 1.0), 1.0);
}
