#ifdef GL_ES
precision mediump float;
#endif

varying vec4 TEX0;
uniform sampler2D Texture;
uniform vec2 TextureSize;
uniform vec2 OutputSize;

void main()
{
	vec2 uv = TEX0.xy;
	vec2 pixel = floor(uv * TextureSize) + 0.5;
	vec2 baseUv = pixel / TextureSize;
	vec2 texel = 1.0 / TextureSize;
	vec2 f = abs(fract(uv * TextureSize) - 0.5) * 2.0;

	vec3 c = texture2D(Texture, baseUv).rgb;
	vec3 h = texture2D(Texture, baseUv + vec2((uv.x * TextureSize.x > pixel.x ? 1.0 : -1.0) * texel.x, 0.0)).rgb;
	vec3 v = texture2D(Texture, baseUv + vec2(0.0, (uv.y * TextureSize.y > pixel.y ? 1.0 : -1.0) * texel.y)).rgb;

	float nearEdge = smoothstep(0.72, 1.0, max(f.x, f.y));
	vec3 soft = mix(c, (c * 0.72 + h * 0.16 + v * 0.12), nearEdge * 0.18);
	vec3 sharp = soft + (soft - (h + v) * 0.5) * 0.035;

	float scan = mix(0.94, 1.0, step(0.50, fract(gl_FragCoord.y * 0.5)));
	sharp = clamp((sharp - 0.5) * 1.018 + 0.5, 0.0, 1.0) * scan;
	gl_FragColor = vec4(clamp(sharp, 0.0, 1.0), 1.0);
}
